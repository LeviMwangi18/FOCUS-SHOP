# Apiary data takeout March 2nd 2025, 13:15

This archive contains all user API Projects (API Blueprint or Swagger) code.

## Content

- README.txt - this file
- APIPROJECTS - Directory which contains all the API Projects (.apib for API Blueprint and .yaml for Swagger)

## User Details

User name: levi mungai
User email: mungailevi1@gmail.com